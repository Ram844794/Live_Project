package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilites.libraries;

public class page_4 extends libraries
{
	WebDriver dr;
	WebElement we;
	
	
	public page_4(WebDriver dr)
	{
		this.dr=dr;
	
	}
	
	 By s=By.xpath("//ul[@id='main-nav']//li[1]//a");//xpath for search
	 By p=By.xpath("//ul[@class='product-categories']//li[4]//a");//xpath for product
	 By w=By.xpath("//a[@rel='nofollow']");//xpath for  w
	// By h=By.xpath("//ul[@id='main-nav']//li[5]//a");
	 
	 public void clk_s()
	 {
		 we=clickable(s,50);
		 we.click();
	 }
	 public void clk_productcategory()
	 {
		 we=clickable(p,50);
		 we.click();
	 }
	 public void w1()
	 {
		 we=clickable(w,50);
		 we.click();
	 }
//	 public void h1()
//	 {
//		 we=l.clickable(h,50);
//		 we.click();
//	 }
	//method for operations 
	 public void clk_operations()
	 {
		 this.clk_s();
		 this.clk_productcategory();
		 this.w1();
		// this.h1();
		 
	 }

}
